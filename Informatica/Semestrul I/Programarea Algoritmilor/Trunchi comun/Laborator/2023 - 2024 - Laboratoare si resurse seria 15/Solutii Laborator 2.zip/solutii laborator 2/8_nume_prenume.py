def corect_unul(nume):
    return len(nume) >= 3 and nume.istitle() and nume.isalpha()
def corect(nume):
    x=nume.count("-")
    if x>1:
        return False

    if x==1:
        n1,n2=nume.split("-")
        return corect_unul(n1) and corect_unul(n2)

    else:
        return corect_unul(nume)

ls = input().split(" ")
if len(ls)==2 and corect(ls[0]) and corect(ls[1]):
    print("corect")
else:
    print("gresit")
