s="1v3a1c1a1n1t5a2 1m13a1r4e"
l=[]
i=0
while i<len(s):
    if s[i].isnumeric():
        nr=ord(s[i])-ord('0')
	    #nr=int(s[i])

        while i<len(s) and s[i+1].isnumeric():
            nr = nr*10+ord(s[i+1]) - ord('0') #sau +int(s[i])
            i+=1
        i=i+1
        #l.extend([s[i]]*nr)
        #print(s[i],nr)
        l+=[s[i]]*nr #mai lent l = l+

        i=i+1
s=''.join(l)
#print(l)
print(s)
#decodificarea

rez=""
c_prev=s[0]
k=1
for c in s[1:]:
    #print(c,c_prev,k)
    if c==c_prev:
        k+=1
    else:
        rez+=str(k)+c_prev
        k=1
    c_prev=c
rez+=str(k)+c
print(rez)
