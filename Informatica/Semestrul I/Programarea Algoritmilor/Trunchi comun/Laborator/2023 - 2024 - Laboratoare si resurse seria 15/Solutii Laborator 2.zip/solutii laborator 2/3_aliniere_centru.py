"""2.	 3.	Se citește un cuvânt s de cel mult 10 de caractere.
Sa se afișeze (folosind s[i:j]) pe câte o linie cuvintele obținute succesiv din s
tăind prima și ultima literă (afișate centrat pe 10 de caractere):"""
s="algoritmi"
print(s.center(10))
for i in range((len(s)-1)//2):
    print(s[i+1:-i-1].center(10))

print("{:^10}".format(s))
for i in range((len(s)-1)//2):
    print("{:^10}".format(s[i + 1:-i - 1])) #nu orice caracter de umplere

print(f"{s:^10}")
for i in range((len(s)-1)//2):
    print(f"{s[i + 1:-i - 1]:^10}")

